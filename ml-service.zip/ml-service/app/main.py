"""
RepoPulse AI – Predictive Analytics Engine
FastAPI service for PR risk prediction, sentiment analysis, and burnout scoring.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional
import joblib
import numpy as np
import os
from pathlib import Path

app = FastAPI(
    title="RepoPulse ML Service",
    description="PR Risk Prediction · Sentiment Analysis · Burnout Scoring",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Model loading
# ---------------------------------------------------------------------------
MODEL_PATH = Path(os.getenv("MODEL_PATH", "./models/pr_risk_model.joblib"))
model = None
sentiment_pipeline = None


def load_models():
    global model, sentiment_pipeline
    if MODEL_PATH.exists():
        model = joblib.load(MODEL_PATH)
        print(f"✅ Loaded PR risk model from {MODEL_PATH}")
    else:
        print("⚠️  No trained model found – using heuristic fallback")
        model = None

    # Lazy-load sentiment to keep startup fast
    try:
        from transformers import pipeline
        sentiment_pipeline = pipeline(
            "sentiment-analysis",
            model="distilbert-base-uncased-finetuned-sst-2-english",
            truncation=True,
            max_length=512,
        )
        print("✅ Sentiment pipeline ready")
    except Exception as e:
        print(f"⚠️  Sentiment model not available: {e}")
        sentiment_pipeline = None


@app.on_event("startup")
async def startup():
    load_models()


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------
class PRFeatures(BaseModel):
    additions: int = 0
    deletions: int = 0
    changed_files: int = Field(0, alias="changed_files")
    num_comments: int = 0
    author_experience_days: float = 90.0
    id: Optional[int] = None

    class Config:
        populate_by_name = True


class BatchRequest(BaseModel):
    prs: List[PRFeatures]


class SentimentRequest(BaseModel):
    text: str


class RiskResponse(BaseModel):
    risk_score: float
    risk_level: str
    reasons: List[str]


# ---------------------------------------------------------------------------
# Heuristic fallback (used when no trained model is present)
# ---------------------------------------------------------------------------
def heuristic_risk(features: PRFeatures) -> dict:
    score = 0.0
    reasons = []

    total_lines = features.additions + features.deletions
    if total_lines > 1000:
        score += 0.40
        reasons.append(f"Very large diff: {total_lines} lines")
    elif total_lines > 500:
        score += 0.25
        reasons.append(f"Large diff: {total_lines} lines")
    elif total_lines > 200:
        score += 0.10

    if features.changed_files > 20:
        score += 0.30
        reasons.append(f"Touches {features.changed_files} files")
    elif features.changed_files > 10:
        score += 0.18
        reasons.append(f"Touches {features.changed_files} files")
    elif features.changed_files > 5:
        score += 0.08

    if features.num_comments > 20:
        score += 0.20
        reasons.append(f"High discussion: {features.num_comments} comments")
    elif features.num_comments > 10:
        score += 0.10

    if features.author_experience_days < 14:
        score += 0.15
        reasons.append("Author is relatively new to the codebase")
    elif features.author_experience_days < 45:
        score += 0.05

    score = min(1.0, score)

    if score >= 0.65:
        level = "HIGH"
    elif score >= 0.35:
        level = "MEDIUM"
    else:
        level = "LOW"

    return {"risk_score": round(score, 3), "risk_level": level, "reasons": reasons}


def model_predict(features: PRFeatures) -> dict:
    if model is None:
        return heuristic_risk(features)

    X = np.array([[
        features.additions,
        features.deletions,
        features.changed_files,
        features.num_comments,
        features.author_experience_days,
    ]])

    proba = model.predict_proba(X)[0]
    # Assume class order [LOW, MEDIUM, HIGH] or binary – adapt
    if len(proba) == 3:
        score = proba[1] * 0.5 + proba[2]  # weighted
        pred_class = int(np.argmax(proba))
        level_map = {0: "LOW", 1: "MEDIUM", 2: "HIGH"}
        level = level_map.get(pred_class, "MEDIUM")
    else:
        score = float(proba[1]) if len(proba) > 1 else float(proba[0])
        level = "HIGH" if score >= 0.65 else "MEDIUM" if score >= 0.35 else "LOW"

    # Still generate human-readable reasons from heuristics
    reasons = heuristic_risk(features)["reasons"]
    return {"risk_score": round(float(score), 3), "risk_level": level, "reasons": reasons}


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------
@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "repopulse-ml",
        "model_loaded": model is not None,
        "sentiment_ready": sentiment_pipeline is not None,
    }


@app.post("/predict-pr-risk", response_model=RiskResponse)
def predict_pr_risk(features: PRFeatures):
    result = model_predict(features)
    return result


@app.post("/batch-predict")
def batch_predict(req: BatchRequest):
    predictions = [model_predict(pr) for pr in req.prs]
    return {"predictions": predictions}


@app.post("/sentiment")
def sentiment(req: SentimentRequest):
    text = (req.text or "").strip()
    if not text:
        return {"label": "NEUTRAL", "score": 0.5}

    if sentiment_pipeline is None:
        # Simple keyword fallback
        lower = text.lower()
        neg_words = ["bug", "broken", "hate", "terrible", "wrong", "fail", "issue", "problem"]
        pos_words = ["great", "thanks", "lgtm", "awesome", "nice", "good", "love"]
        neg = sum(1 for w in neg_words if w in lower)
        pos = sum(1 for w in pos_words if w in lower)
        if neg > pos:
            return {"label": "NEGATIVE", "score": 0.7}
        if pos > neg:
            return {"label": "POSITIVE", "score": 0.7}
        return {"label": "NEUTRAL", "score": 0.5}

    try:
        result = sentiment_pipeline(text[:512])[0]
        # Map to our labels
        label = "POSITIVE" if result["label"] == "POSITIVE" else "NEGATIVE"
        return {"label": label, "score": round(result["score"], 3)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/burnout-score")
def burnout_score(data: dict):
    """
    Simple burnout calculation endpoint.
    Expected keys: after_hours_ratio, avg_review_hours, open_pr_count, weekly_commits
    """
    after_hours = float(data.get("after_hours_ratio", 0))
    review_h = float(data.get("avg_review_hours", 12))
    open_prs = int(data.get("open_pr_count", 0))
    commits = int(data.get("weekly_commits", 5))

    score = 0.0
    score += min(0.4, after_hours * 1.2)
    score += min(0.3, max(0, (review_h - 8) / 40))
    score += min(0.2, open_prs / 15)
    score += min(0.1, max(0, (commits - 15) / 30))

    return {"burnout_risk_score": round(min(1.0, score), 3)}
