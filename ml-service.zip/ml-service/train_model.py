"""
Train a simple RandomForestClassifier for PR risk prediction.
Generates synthetic data that mimics real GitHub PR characteristics.
Run once to produce models/pr_risk_model.joblib
"""

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib
from pathlib import Path

def generate_synthetic_data(n=2000):
    rng = np.random.default_rng(42)
    X = []
    y = []

    for _ in range(n):
        additions = int(rng.integers(1, 2000))
        deletions = int(rng.integers(0, 800))
        changed_files = int(rng.integers(1, 40))
        num_comments = int(rng.integers(0, 50))
        experience = float(rng.uniform(1, 365))

        # Label logic (ground truth heuristic)
        score = 0
        if additions + deletions > 800:
            score += 2
        elif additions + deletions > 300:
            score += 1
        if changed_files > 15:
            score += 2
        elif changed_files > 7:
            score += 1
        if num_comments > 20:
            score += 1
        if experience < 30:
            score += 1

        if score >= 3:
            label = 2  # HIGH
        elif score >= 1:
            label = 1  # MEDIUM
        else:
            label = 0  # LOW

        X.append([additions, deletions, changed_files, num_comments, experience])
        y.append(label)

    return np.array(X), np.array(y)


def main():
    print("Generating synthetic training data…")
    X, y = generate_synthetic_data(2500)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    clf = RandomForestClassifier(
        n_estimators=120,
        max_depth=10,
        min_samples_leaf=4,
        random_state=42,
        class_weight="balanced",
    )
    clf.fit(X_train, y_train)

    print(classification_report(y_test, clf.predict(X_test), target_names=["LOW", "MEDIUM", "HIGH"]))

    out = Path("models/pr_risk_model.joblib")
    out.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(clf, out)
    print(f"✅ Model saved to {out}")


if __name__ == "__main__":
    main()
