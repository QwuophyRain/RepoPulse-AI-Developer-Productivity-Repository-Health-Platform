<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="mb-8">
      <h1 class="text-3xl font-bold tracking-tight">Engineering Pulse</h1>
      <p class="mt-1 text-slate-400">DORA metrics, PR risk & team health across connected repositories</p>
    </div>

    <!-- Demo notice -->
    <div class="card p-4 mb-8 border-brand-700/40 bg-brand-950/30 flex items-start gap-3">
      <div class="text-brand-400 text-xl">💡</div>
      <div class="text-sm">
        <p class="font-medium text-brand-300">Demo mode active</p>
        <p class="text-slate-400 mt-0.5">
          Pre-loaded open-source repositories are available without login.
          Connect GitHub to sync your own private repos.
        </p>
      </div>
    </div>

    <div v-if="store.loading && !store.repos.length" class="text-center py-20 text-slate-500">
      Loading repositories…
    </div>

    <div v-else class="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      <router-link
        v-for="repo in store.repos"
        :key="repo.id"
        :to="`/repos/${repo.id}`"
        class="card p-5 hover:border-brand-600/50 transition group"
      >
        <div class="flex items-start justify-between">
          <div>
            <h3 class="font-semibold text-lg group-hover:text-brand-300 transition">
              {{ repo.fullName || `${repo.owner}/${repo.name}` }}
            </h3>
            <p class="text-xs text-slate-500 mt-1 line-clamp-2">{{ repo.description || 'No description' }}</p>
          </div>
          <span
            class="text-xs font-mono px-2 py-1 rounded bg-slate-800 text-slate-300"
          >
            {{ Math.round(repo.healthScore) }}
          </span>
        </div>

        <div class="mt-4 flex items-center gap-4 text-xs text-slate-400">
          <span>{{ repo._count?.pullRequests ?? 0 }} PRs</span>
          <span>{{ repo._count?.contributors ?? 0 }} contributors</span>
          <span v-if="repo.isDemo" class="text-brand-400">Demo</span>
        </div>

        <!-- Mini health bar -->
        <div class="mt-4 h-1.5 rounded-full bg-slate-800 overflow-hidden">
          <div
            class="h-full rounded-full transition-all"
            :class="healthColor(repo.healthScore)"
            :style="{ width: `${repo.healthScore}%` }"
          />
        </div>
      </router-link>
    </div>

    <div v-if="!store.loading && !store.repos.length" class="text-center py-20">
      <p class="text-slate-400 mb-4">No repositories yet.</p>
      <a href="/auth/github" class="btn-primary">Connect GitHub to get started</a>
    </div>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useRepoStore } from '../stores/repo'

const store = useRepoStore()

function healthColor(score) {
  if (score >= 80) return 'bg-emerald-500'
  if (score >= 60) return 'bg-amber-500'
  return 'bg-rose-500'
}

onMounted(() => {
  store.fetchRepos()
})
</script>
