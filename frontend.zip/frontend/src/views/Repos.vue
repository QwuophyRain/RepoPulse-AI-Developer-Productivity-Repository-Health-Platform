<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="flex items-center justify-between mb-8">
      <div>
        <h1 class="text-2xl font-bold">Repositories</h1>
        <p class="text-slate-400 text-sm mt-1">Manage connected GitHub repositories</p>
      </div>
    </div>

    <div class="card overflow-hidden">
      <table class="w-full text-sm">
        <thead class="bg-slate-900/80 text-slate-400 text-left">
          <tr>
            <th class="px-4 py-3 font-medium">Repository</th>
            <th class="px-4 py-3 font-medium">Health</th>
            <th class="px-4 py-3 font-medium">PRs</th>
            <th class="px-4 py-3 font-medium">Last synced</th>
            <th class="px-4 py-3 font-medium"></th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-800">
          <tr v-for="repo in store.repos" :key="repo.id" class="hover:bg-slate-900/50">
            <td class="px-4 py-3">
              <router-link :to="`/repos/${repo.id}`" class="font-medium hover:text-brand-300">
                {{ repo.fullName }}
              </router-link>
              <span v-if="repo.isDemo" class="ml-2 text-xs text-brand-400">demo</span>
            </td>
            <td class="px-4 py-3">
              <span class="font-mono">{{ Math.round(repo.healthScore) }}</span>
            </td>
            <td class="px-4 py-3">{{ repo._count?.pullRequests ?? '—' }}</td>
            <td class="px-4 py-3 text-slate-400">
              {{ repo.lastSyncedAt ? new Date(repo.lastSyncedAt).toLocaleString() : 'Never' }}
            </td>
            <td class="px-4 py-3 text-right">
              <router-link :to="`/repos/${repo.id}`" class="text-brand-400 hover:underline text-xs">
                View →
              </router-link>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useRepoStore } from '../stores/repo'

const store = useRepoStore()
onMounted(() => store.fetchRepos())
</script>
