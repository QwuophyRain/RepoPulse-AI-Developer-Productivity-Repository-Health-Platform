<template>
  <div class="min-h-[60vh] flex items-center justify-center">
    <div class="text-center">
      <div class="animate-pulse text-brand-400 text-lg mb-2">Completing authentication…</div>
      <p class="text-sm text-slate-500">You will be redirected shortly.</p>
    </div>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useAuthStore } from '../stores/auth'

const router = useRouter()
const route = useRoute()
const auth = useAuthStore()

onMounted(() => {
  const token = route.query.token
  if (token) {
    auth.setToken(token)
    auth.tryRestore().then(() => {
      router.replace('/')
    })
  } else {
    router.replace('/')
  }
})
</script>
