<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
      <div>
        <router-link to="/" class="text-xs text-slate-500 hover:text-slate-300">← Back</router-link>
        <h1 class="text-2xl font-bold mt-1">
          {{ store.current?.fullName || 'Loading…' }}
        </h1>
        <p class="text-sm text-slate-400 mt-0.5">{{ store.current?.description }}</p>
      </div>
      <div class="flex items-center gap-3">
        <div v-if="store.syncStatus" class="text-xs text-slate-400">
          <span :class="{
            'text-amber-400': store.syncStatus.status === 'running',
            'text-emerald-400': store.syncStatus.status === 'completed',
            'text-rose-400': store.syncStatus.status === 'failed',
          }">
            {{ store.syncStatus.message }}
          </span>
          <span v-if="store.syncStatus.progress" class="ml-2">{{ store.syncStatus.progress }}%</span>
        </div>
        <button
          @click="syncRepo"
          class="btn-primary text-sm"
          :disabled="syncing"
        >
          {{ syncing ? 'Syncing…' : 'Sync now' }}
        </button>
      </div>
    </div>

    <!-- DORA Cards -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      <div class="card p-4">
        <p class="text-xs text-slate-400 uppercase tracking-wide">Deployment Freq.</p>
        <p class="text-2xl font-bold mt-1">{{ store.dora?.deploymentFrequency ?? '—' }}</p>
        <p class="text-xs text-slate-500 mt-1">merges / week</p>
      </div>
      <div class="card p-4">
        <p class="text-xs text-slate-400 uppercase tracking-wide">Lead Time</p>
        <p class="text-2xl font-bold mt-1">{{ store.dora?.avgLeadTimeHours ?? '—' }}h</p>
        <p class="text-xs text-slate-500 mt-1">avg create → merge</p>
      </div>
      <div class="card p-4">
        <p class="text-xs text-slate-400 uppercase tracking-wide">Change Failure</p>
        <p class="text-2xl font-bold mt-1">{{ store.dora?.changeFailureRate ?? '—' }}%</p>
        <p class="text-xs text-slate-500 mt-1">proxy rate</p>
      </div>
      <div class="card p-4">
        <p class="text-xs text-slate-400 uppercase tracking-wide">Health Score</p>
        <p class="text-2xl font-bold mt-1" :class="healthTextClass">
          {{ store.dora?.healthScore ?? store.current?.healthScore ?? '—' }}
        </p>
        <p class="text-xs text-slate-500 mt-1">composite</p>
      </div>
    </div>

    <div class="grid lg:grid-cols-3 gap-6">
      <!-- PR Risk Table -->
      <div class="lg:col-span-2 card overflow-hidden">
        <div class="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <h2 class="font-semibold">Pull Request Risk</h2>
          <div class="flex gap-2 text-xs">
            <button
              v-for="r in ['ALL', 'HIGH', 'MEDIUM', 'LOW']"
              :key="r"
              @click="riskFilter = r"
              class="px-2 py-1 rounded"
              :class="riskFilter === r ? 'bg-brand-600 text-white' : 'text-slate-400 hover:bg-slate-800'"
            >
              {{ r }}
            </button>
          </div>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-sm">
            <thead class="text-slate-400 text-left bg-slate-900/50">
              <tr>
                <th class="px-4 py-2 font-medium">#</th>
                <th class="px-4 py-2 font-medium">Title</th>
                <th class="px-4 py-2 font-medium">Author</th>
                <th class="px-4 py-2 font-medium">Risk</th>
                <th class="px-4 py-2 font-medium">Size</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800">
              <tr
                v-for="pr in filteredPRs"
                :key="pr.id"
                class="hover:bg-slate-900/60 cursor-pointer"
                @click="selectedPR = pr"
              >
                <td class="px-4 py-2.5 text-slate-500">#{{ pr.prNumber }}</td>
                <td class="px-4 py-2.5 max-w-xs truncate">{{ pr.title }}</td>
                <td class="px-4 py-2.5 text-slate-400">{{ pr.authorUsername }}</td>
                <td class="px-4 py-2.5">
                  <span :class="riskBadge(pr.riskLevel)">{{ pr.riskLevel || '—' }}</span>
                </td>
                <td class="px-4 py-2.5 text-slate-400 font-mono text-xs">
                  +{{ pr.additions }} −{{ pr.deletions }}
                </td>
              </tr>
              <tr v-if="!filteredPRs.length">
                <td colspan="5" class="px-4 py-8 text-center text-slate-500">No PRs match the filter</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Team Health + Contributors -->
      <div class="space-y-6">
        <div class="card p-4">
          <h2 class="font-semibold mb-3">Team Health</h2>
          <div class="space-y-3 text-sm">
            <div class="flex justify-between">
              <span class="text-slate-400">Avg Burnout Risk</span>
              <span class="font-mono">{{ store.teamHealth?.avgBurnoutRisk ?? '—' }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">High Burnout</span>
              <span class="font-mono">{{ store.teamHealth?.highBurnoutCount ?? 0 }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Comments analyzed</span>
              <span class="font-mono">{{ store.teamHealth?.totalCommentsAnalyzed ?? 0 }}</span>
            </div>
            <div v-if="store.teamHealth?.sentiment" class="pt-2 border-t border-slate-800">
              <p class="text-xs text-slate-500 mb-1">Sentiment</p>
              <div class="flex gap-2 text-xs">
                <span class="text-emerald-400">+{{ store.teamHealth.sentiment.POSITIVE || 0 }}</span>
                <span class="text-rose-400">−{{ store.teamHealth.sentiment.NEGATIVE || 0 }}</span>
                <span class="text-slate-400">○{{ store.teamHealth.sentiment.NEUTRAL || 0 }}</span>
              </div>
            </div>
          </div>
        </div>

        <div class="card p-4">
          <h2 class="font-semibold mb-3">Contributors</h2>
          <ul class="space-y-2 text-sm">
            <li
              v-for="c in store.contributors.slice(0, 8)"
              :key="c.id"
              class="flex items-center justify-between"
            >
              <span class="truncate">{{ c.username }}</span>
              <span
                class="text-xs font-mono px-1.5 py-0.5 rounded"
                :class="c.burnoutRiskScore >= 0.6 ? 'bg-rose-500/20 text-rose-400' : 'bg-slate-800 text-slate-400'"
              >
                {{ (c.burnoutRiskScore * 100).toFixed(0) }}%
              </span>
            </li>
            <li v-if="!store.contributors.length" class="text-slate-500 text-xs">No data yet</li>
          </ul>
        </div>
      </div>
    </div>

    <!-- Commit Heatmap -->
    <div class="card p-4 mt-6">
      <h2 class="font-semibold mb-4">Commit Activity (last 90 days)</h2>
      <CommitHeatmap :commits="store.commits" />
    </div>

    <!-- PR Detail Drawer -->
    <PRDetailDrawer :pr="selectedPR" @close="selectedPR = null" />
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import { useRepoStore } from '../stores/repo'
import CommitHeatmap from '../components/CommitHeatmap.vue'
import PRDetailDrawer from '../components/PRDetailDrawer.vue'

const props = defineProps({ id: { type: [String, Number], required: true } })
const store = useRepoStore()
const riskFilter = ref('ALL')
const selectedPR = ref(null)
const syncing = ref(false)

const filteredPRs = computed(() => {
  if (riskFilter.value === 'ALL') return store.prs
  return store.prs.filter((p) => p.riskLevel === riskFilter.value)
})

const healthTextClass = computed(() => {
  const s = store.dora?.healthScore ?? 0
  if (s >= 80) return 'text-emerald-400'
  if (s >= 60) return 'text-amber-400'
  return 'text-rose-400'
})

function riskBadge(level) {
  if (level === 'HIGH') return 'badge-high'
  if (level === 'MEDIUM') return 'badge-medium'
  return 'badge-low'
}

async function loadAll() {
  const id = props.id
  await Promise.all([
    store.fetchRepo(id),
    store.fetchPRs(id),
    store.fetchContributors(id),
    store.fetchDora(id),
    store.fetchTeamHealth(id),
    store.fetchCommits(id),
  ])
  store.connectSocket(id)
}

async function syncRepo() {
  if (!store.current) return
  syncing.value = true
  try {
    await store.triggerSync(store.current.owner, store.current.name)
  } finally {
    syncing.value = false
  }
}

onMounted(loadAll)
onUnmounted(() => store.disconnectSocket())

watch(() => props.id, loadAll)
</script>
