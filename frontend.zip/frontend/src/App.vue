<template>
  <div class="min-h-screen flex flex-col">
    <header class="border-b border-slate-800 bg-slate-950/90 backdrop-blur sticky top-0 z-50">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <router-link to="/" class="flex items-center gap-3">
          <div class="w-9 h-9 rounded-lg bg-gradient-to-br from-brand-400 to-brand-700 flex items-center justify-center font-bold text-white text-lg">
            R
          </div>
          <div>
            <span class="font-semibold text-lg tracking-tight">RepoPulse</span>
            <span class="ml-1 text-xs font-medium text-brand-400">AI</span>
          </div>
        </router-link>

        <nav class="hidden md:flex items-center gap-6 text-sm text-slate-400">
          <router-link to="/" class="hover:text-white transition" active-class="text-white">Dashboard</router-link>
          <router-link to="/repos" class="hover:text-white transition" active-class="text-white">Repositories</router-link>
        </nav>

        <div class="flex items-center gap-3">
          <span v-if="auth.user" class="text-sm text-slate-400">
            {{ auth.user.username }}
          </span>
          <a
            v-if="!auth.user"
            href="/auth/github"
            class="btn-primary text-sm"
          >
            Connect GitHub
          </a>
          <button v-else @click="auth.logout()" class="btn-ghost text-sm">
            Logout
          </button>
        </div>
      </div>
    </header>

    <main class="flex-1">
      <router-view />
    </main>

    <footer class="border-t border-slate-800 py-6 text-center text-xs text-slate-500">
      RepoPulse AI · Engineering Productivity Platform · Demo build
    </footer>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useAuthStore } from './stores/auth'

const auth = useAuthStore()

onMounted(() => {
  auth.tryRestore()
})
</script>
