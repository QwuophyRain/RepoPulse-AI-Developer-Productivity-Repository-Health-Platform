<template>
  <div ref="chartRef" class="w-full h-40" />
</template>

<script setup>
import { ref, onMounted, watch, onUnmounted } from 'vue'
import * as echarts from 'echarts/core'
import { HeatmapChart } from 'echarts/charts'
import {
  TooltipComponent,
  VisualMapComponent,
  CalendarComponent,
  GridComponent,
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'

echarts.use([
  HeatmapChart,
  TooltipComponent,
  VisualMapComponent,
  CalendarComponent,
  GridComponent,
  CanvasRenderer,
])

const props = defineProps({
  commits: { type: Array, default: () => [] },
})

const chartRef = ref(null)
let chart = null

function buildData() {
  // Aggregate commits per day
  const map = {}
  for (const c of props.commits) {
    const day = new Date(c.authoredAt).toISOString().slice(0, 10)
    map[day] = (map[day] || 0) + 1
  }
  return Object.entries(map).map(([date, count]) => [date, count])
}

function render() {
  if (!chartRef.value) return
  if (!chart) chart = echarts.init(chartRef.value, 'dark')

  const end = new Date()
  const start = new Date()
  start.setDate(start.getDate() - 90)

  const data = buildData()

  chart.setOption({
    backgroundColor: 'transparent',
    tooltip: {
      formatter: (p) => `${p.data[0]}: ${p.data[1]} commits`,
    },
    visualMap: {
      min: 0,
      max: Math.max(5, ...data.map((d) => d[1])),
      calculable: false,
      orient: 'horizontal',
      left: 'center',
      bottom: 0,
      inRange: {
        color: ['#1e293b', '#0ea5e9', '#38bdf8', '#7dd3fc'],
      },
      textStyle: { color: '#94a3b8' },
    },
    calendar: {
      top: 30,
      left: 40,
      right: 20,
      bottom: 40,
      cellSize: ['auto', 14],
      range: [start.toISOString().slice(0, 10), end.toISOString().slice(0, 10)],
      itemStyle: {
        borderWidth: 2,
        borderColor: '#0f172a',
      },
      yearLabel: { show: false },
      dayLabel: { color: '#64748b', fontSize: 10 },
      monthLabel: { color: '#94a3b8' },
    },
    series: [
      {
        type: 'heatmap',
        coordinateSystem: 'calendar',
        data,
      },
    ],
  })
}

onMounted(() => {
  render()
  window.addEventListener('resize', () => chart?.resize())
})

watch(() => props.commits, render, { deep: true })

onUnmounted(() => {
  chart?.dispose()
})
</script>
