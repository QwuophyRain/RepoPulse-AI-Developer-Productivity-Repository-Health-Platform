<template>
  <Teleport to="body">
    <div
      v-if="pr"
      class="fixed inset-0 z-50 flex justify-end"
    >
      <div class="absolute inset-0 bg-black/60" @click="$emit('close')" />
      <div class="relative w-full max-w-md bg-slate-900 border-l border-slate-800 shadow-2xl overflow-y-auto">
        <div class="p-6">
          <div class="flex items-start justify-between mb-4">
            <div>
              <span class="text-xs text-slate-500">#{{ pr.prNumber }}</span>
              <h2 class="text-lg font-semibold mt-0.5 leading-snug">{{ pr.title }}</h2>
            </div>
            <button @click="$emit('close')" class="text-slate-400 hover:text-white text-xl leading-none">×</button>
          </div>

          <div class="flex items-center gap-2 mb-6">
            <span :class="riskBadge(pr.riskLevel)">{{ pr.riskLevel }}</span>
            <span class="text-xs text-slate-400">score {{ (pr.riskScore ?? 0).toFixed(2) }}</span>
          </div>

          <div class="space-y-4 text-sm">
            <div>
              <p class="text-xs text-slate-500 uppercase mb-1">Author</p>
              <p>{{ pr.authorUsername }}</p>
            </div>
            <div class="grid grid-cols-3 gap-3">
              <div>
                <p class="text-xs text-slate-500">Additions</p>
                <p class="font-mono text-emerald-400">+{{ pr.additions }}</p>
              </div>
              <div>
                <p class="text-xs text-slate-500">Deletions</p>
                <p class="font-mono text-rose-400">−{{ pr.deletions }}</p>
              </div>
              <div>
                <p class="text-xs text-slate-500">Files</p>
                <p class="font-mono">{{ pr.changedFiles }}</p>
              </div>
            </div>

            <div v-if="reasons.length">
              <p class="text-xs text-slate-500 uppercase mb-2">Why flagged</p>
              <ul class="space-y-1.5">
                <li
                  v-for="(r, i) in reasons"
                  :key="i"
                  class="flex items-start gap-2 text-amber-200/90 bg-amber-500/10 rounded-lg px-3 py-2"
                >
                  <span class="text-amber-400 mt-0.5">⚠</span>
                  <span>{{ r }}</span>
                </li>
              </ul>
            </div>

            <div v-if="pr.comments?.length">
              <p class="text-xs text-slate-500 uppercase mb-2">Recent comments</p>
              <ul class="space-y-2">
                <li
                  v-for="c in pr.comments"
                  :key="c.id"
                  class="bg-slate-800/50 rounded-lg px-3 py-2"
                >
                  <div class="flex items-center justify-between text-xs mb-1">
                    <span class="text-slate-400">{{ c.authorUsername }}</span>
                    <span
                      v-if="c.sentiment"
                      :class="{
                        'text-emerald-400': c.sentiment === 'POSITIVE',
                        'text-rose-400': c.sentiment === 'NEGATIVE',
                        'text-slate-400': c.sentiment === 'NEUTRAL',
                      }"
                    >
                      {{ c.sentiment }}
                    </span>
                  </div>
                  <p class="text-slate-300 line-clamp-3">{{ c.body }}</p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  pr: { type: Object, default: null },
})
defineEmits(['close'])

const reasons = computed(() => {
  if (!props.pr?.riskReasons) return []
  try {
    return typeof props.pr.riskReasons === 'string'
      ? JSON.parse(props.pr.riskReasons)
      : props.pr.riskReasons
  } catch {
    return []
  }
})

function riskBadge(level) {
  if (level === 'HIGH') return 'badge-high'
  if (level === 'MEDIUM') return 'badge-medium'
  return 'badge-low'
}
</script>
