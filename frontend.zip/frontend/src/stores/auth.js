import { defineStore } from 'pinia'
import { ref } from 'vue'
import api from '../api'

export const useAuthStore = defineStore('auth', () => {
  const user = ref(null)
  const token = ref(localStorage.getItem('rp_token') || null)

  function setToken(t) {
    token.value = t
    if (t) localStorage.setItem('rp_token', t)
    else localStorage.removeItem('rp_token')
  }

  async function tryRestore() {
    if (!token.value) return
    try {
      const { data } = await api.get('/auth/me')
      user.value = data.user
    } catch {
      setToken(null)
      user.value = null
    }
  }

  function logout() {
    setToken(null)
    user.value = null
  }

  return { user, token, setToken, tryRestore, logout }
})
