import { defineStore } from 'pinia'
import { ref } from 'vue'
import api from '../api'
import { io } from 'socket.io-client'

export const useRepoStore = defineStore('repo', () => {
  const repos = ref([])
  const current = ref(null)
  const prs = ref([])
  const contributors = ref([])
  const dora = ref(null)
  const teamHealth = ref(null)
  const commits = ref([])
  const loading = ref(false)
  const syncStatus = ref(null)
  let socket = null

  async function fetchRepos() {
    loading.value = true
    try {
      const { data } = await api.get('/api/repos')
      repos.value = data
    } finally {
      loading.value = false
    }
  }

  async function fetchRepo(id) {
    loading.value = true
    try {
      const { data } = await api.get(`/api/repos/${id}`)
      current.value = data
    } finally {
      loading.value = false
    }
  }

  async function fetchPRs(id, params = {}) {
    const { data } = await api.get(`/api/repos/${id}/prs`, { params })
    prs.value = data
  }

  async function fetchContributors(id) {
    const { data } = await api.get(`/api/repos/${id}/contributors`)
    contributors.value = data
  }

  async function fetchDora(id) {
    const { data } = await api.get(`/api/metrics/${id}/dora`)
    dora.value = data
  }

  async function fetchTeamHealth(id) {
    const { data } = await api.get(`/api/metrics/${id}/team-health`)
    teamHealth.value = data
  }

  async function fetchCommits(id) {
    const { data } = await api.get(`/api/repos/${id}/commits`)
    commits.value = data
  }

  async function triggerSync(owner, name) {
    const { data } = await api.post(`/api/repos/${owner}/${name}/sync`)
    return data
  }

  function connectSocket(repoId) {
    if (socket) socket.disconnect()
    const url = import.meta.env.VITE_API_URL || window.location.origin
    socket = io(url, { transports: ['websocket', 'polling'] })
    socket.emit('subscribe:repo', repoId)
    socket.on('sync:progress', (payload) => {
      if (payload.repoId === Number(repoId)) {
        syncStatus.value = payload
      }
    })
  }

  function disconnectSocket() {
    if (socket) {
      socket.disconnect()
      socket = null
    }
  }

  return {
    repos, current, prs, contributors, dora, teamHealth, commits,
    loading, syncStatus,
    fetchRepos, fetchRepo, fetchPRs, fetchContributors,
    fetchDora, fetchTeamHealth, fetchCommits, triggerSync,
    connectSocket, disconnectSocket,
  }
})
