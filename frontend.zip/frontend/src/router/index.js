import { createRouter, createWebHistory } from 'vue-router'
import Dashboard from '../views/Dashboard.vue'
import Repos from '../views/Repos.vue'
import RepoDetail from '../views/RepoDetail.vue'
import AuthCallback from '../views/AuthCallback.vue'

const routes = [
  { path: '/', name: 'dashboard', component: Dashboard },
  { path: '/repos', name: 'repos', component: Repos },
  { path: '/repos/:id', name: 'repo-detail', component: RepoDetail, props: true },
  { path: '/auth/callback', name: 'auth-callback', component: AuthCallback },
]

export default createRouter({
  history: createWebHistory(),
  routes,
})
