const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding demo repositories…');

  // Demo repo 1: vuejs/core style
  const vue = await prisma.repository.upsert({
    where: { githubId: 11730342 },
    update: {},
    create: {
      githubId: 11730342,
      name: 'core',
      owner: 'vuejs',
      fullName: 'vuejs/core',
      description: 'Vue.js is a progressive, incrementally-adoptable JavaScript framework for building UI on the web.',
      healthScore: 87.5,
      isDemo: true,
      lastSyncedAt: new Date(),
    },
  });

  // Demo repo 2: fastapi
  const fastapi = await prisma.repository.upsert({
    where: { githubId: 156578370 },
    update: {},
    create: {
      githubId: 156578370,
      name: 'fastapi',
      owner: 'tiangolo',
      fullName: 'tiangolo/fastapi',
      description: 'FastAPI framework, high performance, easy to learn, fast to code, ready for production',
      healthScore: 92.0,
      isDemo: true,
      lastSyncedAt: new Date(),
    },
  });

  // Sample PRs for vue
  const samplePRs = [
    {
      githubId: 1001,
      prNumber: 10121,
      title: 'fix: improve reactivity tracking performance',
      state: 'merged',
      authorUsername: 'yyx990803',
      additions: 245,
      deletions: 89,
      changedFiles: 8,
      reviewCommentsCount: 12,
      commentsCount: 5,
      riskScore: 0.28,
      riskLevel: 'LOW',
      riskReasons: JSON.stringify(['Moderate size change']),
      createdAt: new Date(Date.now() - 5 * 24 * 3600 * 1000),
      mergedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000),
      repoId: vue.id,
    },
    {
      githubId: 1002,
      prNumber: 10145,
      title: 'feat: experimental compiler optimizations',
      state: 'open',
      authorUsername: 'pikax',
      additions: 1240,
      deletions: 320,
      changedFiles: 22,
      reviewCommentsCount: 28,
      commentsCount: 15,
      riskScore: 0.78,
      riskLevel: 'HIGH',
      riskReasons: JSON.stringify([
        'Large diff: 1560 lines',
        'Touches 22 files',
        'High discussion: 43 comments',
      ]),
      createdAt: new Date(Date.now() - 2 * 24 * 3600 * 1000),
      repoId: vue.id,
    },
    {
      githubId: 1003,
      prNumber: 10150,
      title: 'chore: update dependencies',
      state: 'merged',
      authorUsername: 'sodatea',
      additions: 45,
      deletions: 38,
      changedFiles: 4,
      reviewCommentsCount: 2,
      commentsCount: 1,
      riskScore: 0.12,
      riskLevel: 'LOW',
      riskReasons: JSON.stringify([]),
      createdAt: new Date(Date.now() - 8 * 24 * 3600 * 1000),
      mergedAt: new Date(Date.now() - 7 * 24 * 3600 * 1000),
      repoId: vue.id,
    },
    {
      githubId: 1004,
      prNumber: 10162,
      title: 'refactor: rewrite effect scheduler',
      state: 'open',
      authorUsername: 'JohnsonChu',
      additions: 680,
      deletions: 410,
      changedFiles: 11,
      reviewCommentsCount: 9,
      commentsCount: 6,
      riskScore: 0.52,
      riskLevel: 'MEDIUM',
      riskReasons: JSON.stringify(['Large diff: 1090 lines', 'Touches 11 files']),
      createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000),
      repoId: vue.id,
    },
  ];

  for (const pr of samplePRs) {
    await prisma.pullRequest.upsert({
      where: { repoId_prNumber: { repoId: pr.repoId, prNumber: pr.prNumber } },
      create: pr,
      update: pr,
    });
  }

  // FastAPI sample PRs
  const fastapiPRs = [
    {
      githubId: 2001,
      prNumber: 11800,
      title: 'Add support for Python 3.13',
      state: 'merged',
      authorUsername: 'tiangolo',
      additions: 180,
      deletions: 45,
      changedFiles: 12,
      reviewCommentsCount: 7,
      riskScore: 0.35,
      riskLevel: 'MEDIUM',
      riskReasons: JSON.stringify(['Touches 12 files']),
      createdAt: new Date(Date.now() - 10 * 24 * 3600 * 1000),
      mergedAt: new Date(Date.now() - 6 * 24 * 3600 * 1000),
      repoId: fastapi.id,
    },
    {
      githubId: 2002,
      prNumber: 11920,
      title: 'Huge: rewrite OpenAPI generation',
      state: 'open',
      authorUsername: 'Kludex',
      additions: 2100,
      deletions: 890,
      changedFiles: 35,
      reviewCommentsCount: 42,
      riskScore: 0.91,
      riskLevel: 'HIGH',
      riskReasons: JSON.stringify([
        'Large diff: 2990 lines',
        'Touches 35 core files',
        'High discussion: 42 comments',
      ]),
      createdAt: new Date(Date.now() - 4 * 24 * 3600 * 1000),
      repoId: fastapi.id,
    },
  ];

  for (const pr of fastapiPRs) {
    await prisma.pullRequest.upsert({
      where: { repoId_prNumber: { repoId: pr.repoId, prNumber: pr.prNumber } },
      create: pr,
      update: pr,
    });
  }

  // Contributors
  const contributors = [
    { username: 'yyx990803', repoId: vue.id, burnoutRiskScore: 0.25, avgReviewHours: 8.5, afterHoursCommitRatio: 0.12, totalCommits: 420 },
    { username: 'pikax', repoId: vue.id, burnoutRiskScore: 0.55, avgReviewHours: 18.2, afterHoursCommitRatio: 0.28, totalCommits: 185 },
    { username: 'sodatea', repoId: vue.id, burnoutRiskScore: 0.18, avgReviewHours: 6.1, afterHoursCommitRatio: 0.08, totalCommits: 310 },
    { username: 'tiangolo', repoId: fastapi.id, burnoutRiskScore: 0.32, avgReviewHours: 10.0, afterHoursCommitRatio: 0.15, totalCommits: 890 },
    { username: 'Kludex', repoId: fastapi.id, burnoutRiskScore: 0.68, avgReviewHours: 22.5, afterHoursCommitRatio: 0.41, totalCommits: 240 },
  ];

  for (const c of contributors) {
    await prisma.contributorMetric.upsert({
      where: { repoId_username: { repoId: c.repoId, username: c.username } },
      create: c,
      update: c,
    });
  }

  // Sample commits for heatmap (last 90 days)
  const authors = ['yyx990803', 'pikax', 'sodatea', 'JohnsonChu'];
  for (let d = 0; d < 90; d++) {
    const date = new Date();
    date.setDate(date.getDate() - d);
    const count = Math.floor(Math.random() * 6);
    for (let i = 0; i < count; i++) {
      const author = authors[Math.floor(Math.random() * authors.length)];
      await prisma.commit.create({
        data: {
          sha: `demo${d}${i}${Math.random().toString(36).slice(2, 8)}`,
          message: `chore: daily work ${d}-${i}`,
          authorUsername: author,
          authoredAt: date,
          additions: Math.floor(Math.random() * 100),
          deletions: Math.floor(Math.random() * 40),
          repoId: vue.id,
        },
      }).catch(() => {});
    }
  }

  console.log('✅ Seed complete');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
