require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const passport = require('passport');

const authRoutes = require('./routes/auth');
const repoRoutes = require('./routes/repos');
const metricsRoutes = require('./routes/metrics');
const { setupPassport } = require('./services/passport');
const { connectRedis } = require('./services/redis');
const { startWorkers } = require('./workers/ingestionWorker');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

// Make io available globally for workers
global.io = io;

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(passport.initialize());
setupPassport();

// Routes
app.use('/auth', authRoutes);
app.use('/api/repos', repoRoutes);
app.use('/api/metrics', metricsRoutes);

app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'repopulse-backend', timestamp: new Date().toISOString() });
});

// Socket.io connection
io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`);
  socket.on('subscribe:repo', (repoId) => {
    socket.join(`repo:${repoId}`);
  });
  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`);
  });
});

const PORT = process.env.PORT || 3000;

async function start() {
  try {
    await connectRedis();
    startWorkers();
    server.listen(PORT, () => {
      console.log(`🚀 RepoPulse Backend running on http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

start();
