const { Worker } = require('bullmq');
const { getRedis } = require('../services/redis');
const { prisma } = require('../services/prisma');
const github = require('../services/github');
const ml = require('../services/mlClient');

function emitProgress(repoId, status, progress, message) {
  if (global.io) {
    global.io.to(`repo:${repoId}`).emit('sync:progress', { repoId, status, progress, message });
  }
}

async function processSyncJob(job) {
  const { repoId, owner, name, accessToken } = job.data;
  console.log(`🔄 Starting sync for ${owner}/${name} (repoId=${repoId})`);

  const token = accessToken || process.env.GITHUB_TOKEN;
  if (!token) {
    throw new Error('No GitHub access token available. Configure GITHUB_TOKEN or authenticate.');
  }

  try {
    emitProgress(repoId, 'running', 5, 'Fetching repository metadata…');

    // 1. Repo metadata
    const ghRepo = await github.fetchRepo(owner, name, token);
    await prisma.repository.update({
      where: { id: repoId },
      data: {
        githubId: ghRepo.id,
        description: ghRepo.description,
        fullName: ghRepo.full_name,
        lastSyncedAt: new Date(),
      },
    });

    // 2. Pull Requests
    emitProgress(repoId, 'running', 20, 'Fetching pull requests…');
    const prs = await github.fetchPullRequests(owner, name, token, 50);

    const prRecords = [];
    for (let i = 0; i < prs.length; i++) {
      const pr = prs[i];
      const detailed = await github.fetchPullRequest(owner, name, pr.number, token).catch(() => pr);

      prRecords.push({
        githubId: pr.id,
        prNumber: pr.number,
        title: pr.title,
        body: pr.body?.slice(0, 5000) || null,
        state: pr.merged_at ? 'merged' : pr.state,
        authorUsername: pr.user?.login || 'unknown',
        additions: detailed.additions || 0,
        deletions: detailed.deletions || 0,
        changedFiles: detailed.changed_files || 0,
        reviewCommentsCount: detailed.review_comments || 0,
        commentsCount: detailed.comments || 0,
        commitsCount: detailed.commits || 0,
        createdAt: new Date(pr.created_at),
        updatedAt: pr.updated_at ? new Date(pr.updated_at) : null,
        mergedAt: pr.merged_at ? new Date(pr.merged_at) : null,
        closedAt: pr.closed_at ? new Date(pr.closed_at) : null,
        repoId,
      });

      if (i % 10 === 0) {
        emitProgress(repoId, 'running', 20 + Math.floor((i / prs.length) * 30), `Processing PR #${pr.number}…`);
      }
    }

    // Upsert PRs
    for (const rec of prRecords) {
      await prisma.pullRequest.upsert({
        where: { repoId_prNumber: { repoId, prNumber: rec.prNumber } },
        create: rec,
        update: rec,
      });
    }

    // 3. ML Risk scoring
    emitProgress(repoId, 'running', 55, 'Running ML risk predictions…');
    const storedPrs = await prisma.pullRequest.findMany({ where: { repoId } });
    const features = storedPrs.map((p) => ({
      id: p.id,
      additions: p.additions,
      deletions: p.deletions,
      changed_files: p.changedFiles,
      num_comments: p.reviewCommentsCount + p.commentsCount,
      author_experience_days: 90, // placeholder – could be computed
    }));

    const predictions = await ml.batchPredict(features);

    for (let i = 0; i < storedPrs.length; i++) {
      const pred = predictions[i] || { risk_score: 0.3, risk_level: 'LOW', reasons: [] };
      await prisma.pullRequest.update({
        where: { id: storedPrs[i].id },
        data: {
          riskScore: pred.risk_score,
          riskLevel: pred.risk_level,
          riskReasons: JSON.stringify(pred.reasons || []),
        },
      });
    }

    // 4. Comments + Sentiment (sample first 15 PRs)
    emitProgress(repoId, 'running', 70, 'Analyzing comment sentiment…');
    const samplePrs = storedPrs.slice(0, 15);
    for (const pr of samplePrs) {
      try {
        const comments = await github.fetchPRComments(owner, name, pr.prNumber, token);
        for (const c of comments.slice(0, 8)) {
          const sentiment = await ml.analyzeSentiment(c.body || '');
          await prisma.comment.create({
            data: {
              githubId: c.id,
              body: (c.body || '').slice(0, 2000),
              authorUsername: c.user?.login || 'unknown',
              sentiment: sentiment.label,
              sentimentScore: sentiment.score,
              createdAt: new Date(c.created_at),
              prId: pr.id,
            },
          }).catch(() => {}); // ignore duplicates
        }
      } catch (e) {
        // rate limit or missing – continue
      }
    }

    // 5. Commits
    emitProgress(repoId, 'running', 85, 'Fetching commits…');
    const commits = await github.fetchCommits(owner, name, token, 100);
    for (const c of commits) {
      await prisma.commit.upsert({
        where: { repoId_sha: { repoId, sha: c.sha } },
        create: {
          sha: c.sha,
          message: (c.commit?.message || '').slice(0, 500),
          authorUsername: c.author?.login || c.commit?.author?.name || 'unknown',
          authoredAt: new Date(c.commit?.author?.date || Date.now()),
          additions: c.stats?.additions || 0,
          deletions: c.stats?.deletions || 0,
          repoId,
        },
        update: {},
      }).catch(() => {});
    }

    // 6. Contributor metrics (simple aggregation)
    emitProgress(repoId, 'running', 95, 'Computing contributor metrics…');
    const allCommits = await prisma.commit.findMany({ where: { repoId } });
    const byUser = {};
    for (const c of allCommits) {
      if (!byUser[c.authorUsername]) {
        byUser[c.authorUsername] = { totalCommits: 0, afterHours: 0 };
      }
      byUser[c.authorUsername].totalCommits += 1;
      const hour = new Date(c.authoredAt).getHours();
      if (hour < 7 || hour > 20) byUser[c.authorUsername].afterHours += 1;
    }

    for (const [username, stats] of Object.entries(byUser)) {
      const afterHoursRatio = stats.totalCommits ? stats.afterHours / stats.totalCommits : 0;
      // Simple burnout heuristic
      const burnout = Math.min(1, afterHoursRatio * 1.5 + (stats.totalCommits > 40 ? 0.2 : 0));

      await prisma.contributorMetric.upsert({
        where: { repoId_username: { repoId, username } },
        create: {
          username,
          repoId,
          totalCommits: stats.totalCommits,
          afterHoursCommitRatio: afterHoursRatio,
          burnoutRiskScore: burnout,
          avgReviewHours: 12 + Math.random() * 24, // placeholder
        },
        update: {
          totalCommits: stats.totalCommits,
          afterHoursCommitRatio: afterHoursRatio,
          burnoutRiskScore: burnout,
        },
      });
    }

    // Final health score update
    const dora = await computeSimpleHealth(repoId);
    await prisma.repository.update({
      where: { id: repoId },
      data: { healthScore: dora, lastSyncedAt: new Date() },
    });

    emitProgress(repoId, 'completed', 100, 'Sync completed successfully');
    console.log(`✅ Sync finished for ${owner}/${name}`);
  } catch (err) {
    console.error(`❌ Sync failed for ${owner}/${name}:`, err.message);
    emitProgress(repoId, 'failed', 0, err.message);
    throw err;
  }
}

async function computeSimpleHealth(repoId) {
  const prs = await prisma.pullRequest.findMany({ where: { repoId } });
  if (!prs.length) return 80;
  const highRisk = prs.filter((p) => p.riskLevel === 'HIGH').length;
  const ratio = highRisk / prs.length;
  return Math.max(20, Math.round(100 - ratio * 60));
}

function startWorkers() {
  const connection = getRedis();
  const worker = new Worker(
    'ingestion',
    async (job) => {
      if (job.name === 'sync-repo') {
        await processSyncJob(job);
      }
    },
    { connection, concurrency: 1 } // respect GitHub rate limits
  );

  worker.on('completed', (job) => console.log(`Job ${job.id} completed`));
  worker.on('failed', (job, err) => console.error(`Job ${job?.id} failed:`, err.message));

  console.log('👷 Ingestion worker started');
  return worker;
}

module.exports = { startWorkers, processSyncJob };
