const express = require('express');
const { prisma } = require('../services/prisma');

const router = express.Router();

/**
 * Compute DORA-style metrics for a repository
 */
router.get('/:repoId/dora', async (req, res) => {
  try {
    const repoId = parseInt(req.params.repoId);
    const days = parseInt(req.query.days) || 30;
    const since = new Date();
    since.setDate(since.getDate() - days);

    const prs = await prisma.pullRequest.findMany({
      where: {
        repoId,
        createdAt: { gte: since },
      },
    });

    const merged = prs.filter((p) => p.mergedAt);
    const closed = prs.filter((p) => p.closedAt && !p.mergedAt);

    // Deployment Frequency ≈ merge frequency
    const deploymentFrequency = merged.length / (days / 7); // per week

    // Lead Time (approx) = time from creation to merge
    const leadTimes = merged
      .filter((p) => p.mergedAt && p.createdAt)
      .map((p) => (new Date(p.mergedAt) - new Date(p.createdAt)) / (1000 * 60 * 60)); // hours
    const avgLeadTimeHours = leadTimes.length
      ? leadTimes.reduce((a, b) => a + b, 0) / leadTimes.length
      : 0;

    // Change Failure Rate (proxy: closed without merge / total closed)
    const totalClosed = closed.length + merged.length;
    const changeFailureRate = totalClosed ? (closed.length / totalClosed) * 100 : 0;

    // MTTR proxy – average time from close to next successful merge (simplified)
    // For demo we use average review/merge lag of failed ones
    const mttrHours = avgLeadTimeHours * 0.4; // simplified heuristic

    // Health score (simple composite)
    let health = 100;
    if (deploymentFrequency < 1) health -= 15;
    if (avgLeadTimeHours > 72) health -= 20;
    if (changeFailureRate > 20) health -= 25;
    health = Math.max(0, Math.min(100, health));

    // Risk distribution
    const riskDist = { LOW: 0, MEDIUM: 0, HIGH: 0 };
    prs.forEach((p) => {
      if (p.riskLevel) riskDist[p.riskLevel] = (riskDist[p.riskLevel] || 0) + 1;
    });

    res.json({
      periodDays: days,
      deploymentFrequency: Math.round(deploymentFrequency * 100) / 100,
      avgLeadTimeHours: Math.round(avgLeadTimeHours * 10) / 10,
      changeFailureRate: Math.round(changeFailureRate * 10) / 10,
      mttrHours: Math.round(mttrHours * 10) / 10,
      healthScore: Math.round(health),
      totalPRs: prs.length,
      mergedPRs: merged.length,
      riskDistribution: riskDist,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Aggregate burnout / sentiment overview
 */
router.get('/:repoId/team-health', async (req, res) => {
  try {
    const repoId = parseInt(req.params.repoId);

    const contributors = await prisma.contributorMetric.findMany({
      where: { repoId },
    });

    const highBurnout = contributors.filter((c) => c.burnoutRiskScore >= 0.6).length;
    const avgBurnout =
      contributors.length === 0
        ? 0
        : contributors.reduce((s, c) => s + c.burnoutRiskScore, 0) / contributors.length;

    // Sentiment from recent comments
    const comments = await prisma.comment.findMany({
      where: {
        OR: [
          { pullRequest: { repoId } },
          { issue: { repoId } },
        ],
      },
      take: 200,
      orderBy: { createdAt: 'desc' },
    });

    const sentimentCounts = { POSITIVE: 0, NEGATIVE: 0, NEUTRAL: 0 };
    comments.forEach((c) => {
      if (c.sentiment) sentimentCounts[c.sentiment] = (sentimentCounts[c.sentiment] || 0) + 1;
    });

    res.json({
      contributorCount: contributors.length,
      avgBurnoutRisk: Math.round(avgBurnout * 100) / 100,
      highBurnoutCount: highBurnout,
      sentiment: sentimentCounts,
      totalCommentsAnalyzed: comments.length,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
