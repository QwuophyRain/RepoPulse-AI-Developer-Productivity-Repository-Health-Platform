const express = require('express');
const { prisma } = require('../services/prisma');
const { getIngestionQueue } = require('../services/redis');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

// List repositories (demo + user's)
router.get('/', async (req, res) => {
  try {
    const repos = await prisma.repository.findMany({
      orderBy: { updatedAt: 'desc' },
      include: {
        _count: { select: { pullRequests: true, contributors: true } },
      },
    });
    res.json(repos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single repository
router.get('/:id', async (req, res) => {
  try {
    const repo = await prisma.repository.findUnique({
      where: { id: parseInt(req.params.id) },
      include: {
        _count: { select: { pullRequests: true, commits: true, contributors: true } },
      },
    });
    if (!repo) return res.status(404).json({ error: 'Repository not found' });
    res.json(repo);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Trigger sync for a repository
router.post('/:owner/:name/sync', authMiddleware, async (req, res) => {
  try {
    const { owner, name } = req.params;
    const fullName = `${owner}/${name}`;

    let repo = await prisma.repository.findFirst({
      where: { fullName },
    });

    if (!repo) {
      // Create placeholder – worker will fill details
      repo = await prisma.repository.create({
        data: {
          githubId: 0, // temporary
          name,
          owner,
          fullName,
          userId: req.user?.id || null,
        },
      });
    }

    const queue = getIngestionQueue();
    const job = await queue.add('sync-repo', {
      repoId: repo.id,
      owner,
      name,
      accessToken: req.user?.accessToken || process.env.GITHUB_TOKEN || null,
      userId: req.user?.id,
    });

    // Create sync job record
    await prisma.syncJob.create({
      data: {
        repoId: repo.id,
        status: 'pending',
        message: `Job ${job.id} queued`,
      },
    });

    res.json({ message: 'Sync started', jobId: job.id, repoId: repo.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get PRs for a repo
router.get('/:id/prs', async (req, res) => {
  try {
    const repoId = parseInt(req.params.id);
    const { risk, state, limit = 50 } = req.query;

    const where = { repoId };
    if (risk) where.riskLevel = risk.toUpperCase();
    if (state) where.state = state;

    const prs = await prisma.pullRequest.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: parseInt(limit),
      include: {
        comments: {
          select: { id: true, body: true, authorUsername: true, sentiment: true, sentimentScore: true },
          take: 5,
        },
      },
    });
    res.json(prs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get contributors for a repo
router.get('/:id/contributors', async (req, res) => {
  try {
    const contributors = await prisma.contributorMetric.findMany({
      where: { repoId: parseInt(req.params.id) },
      orderBy: { burnoutRiskScore: 'desc' },
    });
    res.json(contributors);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get commits (for heatmap)
router.get('/:id/commits', async (req, res) => {
  try {
    const { from, to } = req.query;
    const where = { repoId: parseInt(req.params.id) };
    if (from || to) {
      where.authoredAt = {};
      if (from) where.authoredAt.gte = new Date(from);
      if (to) where.authoredAt.lte = new Date(to);
    }

    const commits = await prisma.commit.findMany({
      where,
      select: {
        id: true,
        sha: true,
        message: true,
        authorUsername: true,
        authoredAt: true,
        additions: true,
        deletions: true,
      },
      orderBy: { authoredAt: 'desc' },
      take: 500,
    });
    res.json(commits);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
