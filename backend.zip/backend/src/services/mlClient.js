const axios = require('axios');

const ML_URL = process.env.ML_SERVICE_URL || 'http://localhost:8000';

async function predictPRRisk(features) {
  try {
    const { data } = await axios.post(`${ML_URL}/predict-pr-risk`, features, {
      timeout: 15000,
    });
    return data;
  } catch (err) {
    console.error('ML predict error:', err.message);
    // Fallback heuristic if ML service is down
    return heuristicRisk(features);
  }
}

async function batchPredict(prs) {
  try {
    const { data } = await axios.post(`${ML_URL}/batch-predict`, { prs }, {
      timeout: 30000,
    });
    return data.predictions;
  } catch (err) {
    console.error('ML batch error:', err.message);
    return prs.map((p) => heuristicRisk(p));
  }
}

async function analyzeSentiment(text) {
  try {
    const { data } = await axios.post(`${ML_URL}/sentiment`, { text }, {
      timeout: 10000,
    });
    return data;
  } catch (err) {
    return { label: 'NEUTRAL', score: 0.5 };
  }
}

function heuristicRisk(f) {
  let score = 0;
  const additions = f.additions || 0;
  const deletions = f.deletions || 0;
  const changedFiles = f.changed_files || f.changedFiles || 0;
  const comments = f.num_comments || f.reviewCommentsCount || 0;

  if (additions + deletions > 800) score += 0.35;
  else if (additions + deletions > 400) score += 0.2;
  if (changedFiles > 12) score += 0.25;
  else if (changedFiles > 6) score += 0.12;
  if (comments > 15) score += 0.15;
  if ((f.author_experience_days || 30) < 14) score += 0.15;

  score = Math.min(1, score);
  let level = 'LOW';
  if (score >= 0.65) level = 'HIGH';
  else if (score >= 0.35) level = 'MEDIUM';

  const reasons = [];
  if (additions + deletions > 400) reasons.push(`Large diff: ${additions + deletions} lines`);
  if (changedFiles > 6) reasons.push(`Touches ${changedFiles} files`);
  if (comments > 10) reasons.push(`High discussion: ${comments} comments`);

  return { risk_score: score, risk_level: level, reasons };
}

module.exports = { predictPRRisk, batchPredict, analyzeSentiment };
