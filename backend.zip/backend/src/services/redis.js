const Redis = require('ioredis');
const { Queue } = require('bullmq');

let redis = null;
let ingestionQueue = null;

function connectRedis() {
  const url = process.env.REDIS_URL || 'redis://localhost:6379';
  redis = new Redis(url, {
    maxRetriesPerRequest: null,
  });

  redis.on('connect', () => console.log('✅ Redis connected'));
  redis.on('error', (err) => console.error('Redis error:', err.message));

  ingestionQueue = new Queue('ingestion', {
    connection: redis,
    defaultJobOptions: {
      attempts: 3,
      backoff: { type: 'exponential', delay: 5000 },
      removeOnComplete: 100,
      removeOnFail: 50,
    },
  });

  return redis;
}

function getRedis() {
  if (!redis) throw new Error('Redis not connected');
  return redis;
}

function getIngestionQueue() {
  if (!ingestionQueue) throw new Error('Ingestion queue not initialized');
  return ingestionQueue;
}

module.exports = { connectRedis, getRedis, getIngestionQueue };
