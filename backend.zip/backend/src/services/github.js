const axios = require('axios');

const GITHUB_API = 'https://api.github.com';

function createClient(accessToken) {
  return axios.create({
    baseURL: GITHUB_API,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
    },
  });
}

/**
 * Fetch last N pull requests for a repository
 */
async function fetchPullRequests(owner, repo, accessToken, perPage = 50, page = 1) {
  const client = createClient(accessToken);
  const { data } = await client.get(`/repos/${owner}/${repo}/pulls`, {
    params: { state: 'all', per_page: perPage, page, sort: 'updated', direction: 'desc' },
  });
  return data;
}

/**
 * Fetch a single PR with more details
 */
async function fetchPullRequest(owner, repo, prNumber, accessToken) {
  const client = createClient(accessToken);
  const { data } = await client.get(`/repos/${owner}/${repo}/pulls/${prNumber}`);
  return data;
}

/**
 * Fetch review comments for a PR
 */
async function fetchPRComments(owner, repo, prNumber, accessToken) {
  const client = createClient(accessToken);
  const [reviewComments, issueComments] = await Promise.all([
    client.get(`/repos/${owner}/${repo}/pulls/${prNumber}/comments`).then((r) => r.data),
    client.get(`/repos/${owner}/${repo}/issues/${prNumber}/comments`).then((r) => r.data),
  ]);
  return [...reviewComments, ...issueComments];
}

/**
 * Fetch recent commits
 */
async function fetchCommits(owner, repo, accessToken, perPage = 100) {
  const client = createClient(accessToken);
  const { data } = await client.get(`/repos/${owner}/${repo}/commits`, {
    params: { per_page: perPage },
  });
  return data;
}

/**
 * Fetch repository metadata
 */
async function fetchRepo(owner, repo, accessToken) {
  const client = createClient(accessToken);
  const { data } = await client.get(`/repos/${owner}/${repo}`);
  return data;
}

/**
 * Rate limit helper – GitHub returns remaining in headers
 */
function getRateLimitRemaining(response) {
  return parseInt(response.headers['x-ratelimit-remaining'] || '0', 10);
}

module.exports = {
  createClient,
  fetchPullRequests,
  fetchPullRequest,
  fetchPRComments,
  fetchCommits,
  fetchRepo,
  getRateLimitRemaining,
};
