const passport = require('passport');
const GitHubStrategy = require('passport-github2').Strategy;
const { prisma } = require('./prisma');
const jwt = require('jsonwebtoken');

function setupPassport() {
  if (!process.env.GITHUB_CLIENT_ID || !process.env.GITHUB_CLIENT_SECRET) {
    console.warn('⚠️  GitHub OAuth credentials not set – auth routes will fail until configured.');
    return;
  }

  passport.use(
    new GitHubStrategy(
      {
        clientID: process.env.GITHUB_CLIENT_ID,
        clientSecret: process.env.GITHUB_CLIENT_SECRET,
        callbackURL: process.env.GITHUB_CALLBACK_URL,
        scope: ['user:email', 'repo', 'read:org'],
      },
      async (accessToken, refreshToken, profile, done) => {
        try {
          let user = await prisma.user.findUnique({
            where: { githubId: parseInt(profile.id) },
          });

          if (!user) {
            user = await prisma.user.create({
              data: {
                githubId: parseInt(profile.id),
                username: profile.username,
                avatarUrl: profile.photos?.[0]?.value || null,
                accessToken,
              },
            });
          } else {
            user = await prisma.user.update({
              where: { id: user.id },
              data: { accessToken, avatarUrl: profile.photos?.[0]?.value || user.avatarUrl },
            });
          }

          return done(null, user);
        } catch (err) {
          return done(err);
        }
      }
    )
  );
}

function generateToken(user) {
  return jwt.sign(
    { id: user.id, username: user.username, githubId: user.githubId },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
}

function verifyToken(token) {
  return jwt.verify(token, process.env.JWT_SECRET);
}

module.exports = { setupPassport, generateToken, verifyToken };
