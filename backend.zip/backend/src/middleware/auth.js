const { verifyToken } = require('../services/passport');
const { prisma } = require('../services/prisma');

async function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    // Allow anonymous for demo endpoints, but mark as unauthenticated
    req.user = null;
    return next();
  }

  try {
    const payload = verifyToken(authHeader.slice(7));
    const user = await prisma.user.findUnique({ where: { id: payload.id } });
    if (!user) return res.status(401).json({ error: 'User not found' });
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

module.exports = { authMiddleware };
