# RepoPulse AI — Architecture Notes

## High-level flow

1. **User authenticates** via GitHub OAuth (Passport.js).
2. **User triggers a sync** for a repository → BullMQ job is enqueued.
3. **Ingestion worker** (concurrency 1 to respect rate limits):
   - Fetches repo metadata, PRs, comments, commits via GitHub REST API.
   - Upserts into PostgreSQL (Prisma).
   - Calls Python ML service for risk scores + sentiment.
   - Computes contributor burnout heuristics.
   - Emits progress over Socket.io.
4. **Dashboard** consumes REST + WebSocket:
   - DORA cards derived from PR merge history.
   - PR Risk table with expandable drawer (reasons from ML).
   - Apache ECharts calendar heatmap of commits.
   - Team health / sentiment summary.

## ML Service

- **PR Risk**: RandomForestClassifier trained on synthetic data that mirrors real PR size / complexity distributions. Falls back to a transparent heuristic when the model file is absent.
- **Sentiment**: HuggingFace `distilbert-base-uncased-finetuned-sst-2-english` with keyword fallback.
- **Burnout**: Lightweight formula combining after-hours commit ratio, review lag, open PR backlog.

## Security notes for production

- Never expose `accessToken` to the frontend.
- Rotate JWT secret and use short-lived tokens + refresh.
- GitHub App (preferred) over OAuth user tokens for higher rate limits and installation-level scopes.
- Add rate-limit middleware on public endpoints.
- Encrypt tokens at rest (or use a secrets manager).

## Extending

- GraphQL ingestion for richer review thread data.
- Real deployment / incident data (from GitHub Deployments or external CI) for accurate Change Failure Rate & MTTR.
- Multi-org support and role-based access control.
